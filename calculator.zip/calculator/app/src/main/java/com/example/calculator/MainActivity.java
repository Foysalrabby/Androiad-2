package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
        String op="+";
        String oldnumber="";
        EditText editdis;
        boolean isNewop=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editdis=findViewById(R.id.editdis);
    }

    public void numberEvent(View view) {
        if(isNewop)
            editdis.setText("");
        isNewop=false;
     String number=editdis.getText().toString();
     switch(view.getId()){
         case R.id.button1:
             number= number + "1";
             break;
         case R.id.button2:
             number= number + "2";
             break;
         case R.id.button3:
             number= number + "3";
             break;
         case R.id.button4:
             number= number + "4";
             break;
         case R.id.button5:
             number= number + "5";
             break;
         case R.id.button6:
             number= number + "6";
             break;
         case R.id.button7:
             number= number + "7";
             break;
         case R.id.button8:
             number= number + "8";
             break;
         case R.id.button9:
             number= number + "9";
             break;
         case R.id.button0:
             number= number + "0";
             break;
         case R.id.buttondot:
             number= number + ".";
             break;

     }
    editdis.setText(number);

    }


    public void clearEvent(View view) {
        editdis.setText("");
    }

    public void operatorEvent(View view) {
        isNewop=true;
        oldnumber=editdis.getText().toString();
        switch (view.getId()){
            case R.id.buttoncadd:
                op="+";
                break;
            case R.id.buttonsub:
                op="-";
                break;
            case R.id.buttonmul:
                op="*";
                break;
            case R.id.buttondiv:
                op="/";
                break;
        }

    }

    public void resultEvent(View view) {
        double result=0.0;
        String newnumber=editdis.getText().toString();
        switch(op){
            case "+":
                result=Double.parseDouble(oldnumber)+Double.parseDouble(newnumber);
                break;
            case "-":
                result=Double.parseDouble(oldnumber)-Double.parseDouble(newnumber);
                break;
            case "*":
                result=Double.parseDouble(oldnumber)*Double.parseDouble(newnumber);
                break;
            case "/":
                result=Double.parseDouble(oldnumber)/Double.parseDouble(newnumber);
                break;
        }
        editdis.setText(result +"");
    }
}